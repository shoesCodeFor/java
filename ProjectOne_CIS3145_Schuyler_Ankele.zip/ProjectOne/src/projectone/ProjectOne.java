/*
 * Author: Schuyler Ankele - SID#900348670 
 * Project 1 - Monthly Payment Calculator
 * 6/24/2016
 * This program provides a monthly payment amount based on interest rate, amount
 * of the loan and the duration of the loan.
 */


 /* Additional Specs - Input requirements must be within range.
                       Greater    Less
                       Than       Than
Loan amount:           0          1,000,000
Yearly interest rate:  0          20
Years:                 0          100


*/
package projectone;

import java.util.InputMismatchException;
import java.text.NumberFormat;
import Console.*;
import calculators.MonthlyPayment;

public class ProjectOne {
        
  
    public static void main(String[] args) {
        // Declare variables
        String userMsg = "Welcome to the Monthly Payment Calculator";
        String loanMsg = "Please enter the amount of the loan";
        String rateMsg = "Please enter the interest rate of your loan";
        String durationMsg = "Please enter the length of the loan in years";
        
        // Set ranges for acceptable inputs
        int yearMin = 0;
        int yearMax = 100;
        double minAPR = 0;
        double maxAPR = 20;
        double minLoan = 0;
        double maxLoan = 1000000;
        double loanAmt;
        double aprRate;
        int monthsOfLoan;
        int years;
        double monthlyPmt = 0;
        
        String pmtMsg;
        String proceedPrompt = "Would you like to continue? (y/n)";
        String choice = "y";
        String error;
        boolean goOn = false;
        
        do{ 
            
                
            // Start of program methods
            Output.sendToConsole(userMsg);
            Output.lineBreak();

            // Let's start collecting input
            loanAmt = Input.getDouble(loanMsg, minLoan, maxLoan);
            aprRate = Input.getDouble(rateMsg, minAPR, maxAPR);
            years = Input.getInt(durationMsg, yearMin, yearMax);
            // Convert the years to months upon input
            monthsOfLoan = years * 12;
            // Pass variables to method for calculation
            monthlyPmt = MonthlyPayment.calculatePayment(loanAmt, aprRate, 
                    monthsOfLoan);

            // Convert the double to a string with formatting
            pmtMsg = NumberFormat.getCurrencyInstance().format(monthlyPmt);

            // Print finished report to console
            Output.sendToConsole("FORMATTED RESULTS");
            Output.sendToConsole("Loan amount:          $" + loanAmt);
            Output.sendToConsole("Yearly interest rate: " +  "%" + aprRate);
            Output.sendToConsole("Number of years:      "+ years);
            Output.sendToConsole("Monthly payment:      " + pmtMsg);
            
            
            // We will give the user 2 attempts to enter a correct reply
            try{
                Console.Output.sendToConsole("Would you like to continue?");
                choice = Console.Input.getString();
                choice = choice.toLowerCase();
            
            }
            catch(InputMismatchException e){
                System.err.println(e.toString());
                break;
            }
            catch(NullPointerException e){
                System.err.println(e.toString());
                break;
            }
            catch(Exception e){
                System.err.println(e.toString());
                break;
            }
            if(choice.equalsIgnoreCase("n")){
                Console.Output.sendToConsole("Goodbye!");
                System.exit(1);
            }
            else if(!choice.equalsIgnoreCase("y")){
                Console.Output.sendToConsole("Please enter y/n or the program "
                        + "will exit.");
                choice = Console.Input.getString();
                choice = choice.toLowerCase();
                if(choice.equalsIgnoreCase("n")){
                    Console.Output.sendToConsole("Goodbye!");
                    System.exit(0);
                }
                if(choice.equalsIgnoreCase("y")){
                    break;
                }
            }
            
            }while(choice.equals("y"));
            
            
            System.exit(0);
            
        }
    }
    

