
package calculators;


public class MonthlyPayment {
    public static double calculatePayment(double loanAmount, 
            double monthlyInterestRate, int months){
                /*  I copied the formula from the assignment doc and got 
                    inaccurate calculations. This has been modified to
                    P = loanAmt, r = APR, m = months 
                      P ( r / 12 )
                    -------------------------
                                       -m 
                    (1 - ( 1 + r / 12 )   )
                */
                // This step converts the APR to a monthly rate
                monthlyInterestRate = (monthlyInterestRate * .01)/12;
                
                // This equation calculates monthly payment
                double monthlyPayment =
                    (loanAmount * (monthlyInterestRate))/
                    (1 - (Math.pow((1 + (monthlyInterestRate))
                            ,((double)months * -1))));
                
                return monthlyPayment;
    }
}
