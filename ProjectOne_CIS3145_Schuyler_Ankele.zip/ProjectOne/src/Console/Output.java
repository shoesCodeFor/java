/*
    This class is intended to mimic the functions found in the Murach 
    Console Class
    
    The Outputs class will take care of displaying thing into the console



*/

package Console;

public class Output {
    
    public static void lineBreak() {
        System.out.println();
    }

    public static void sendToConsole(String oneLine) {
        System.out.println(oneLine);
    }
    
}
